package com.ancorp.cloud.springmicroservicesoauth2secureui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMicroservicesOauth2SecureuiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMicroservicesOauth2SecureuiApplication.class, args);
	}
}
