package com.ancorp.cloud.springmicroservicesoauth2secureui;

//import java.security.Principal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableOAuth2Sso
public class ReportController {
	
	
		@Autowired
		private OAuth2ClientContext clientContext;
		
		@Autowired
		private OAuth2RestTemplate restTemplate;

	
		@RequestMapping(value="/")	
		 public String loadHome(){
			 return "Secure Application Home Url:: " ;
		 }
		
		@RequestMapping(value="/loadReport")
		//This method will call another service using an sso token
		public String loadReport(){
			
			String url = "http://localhost:9001/tollData";
			ResponseEntity<String> responseEntity =  restTemplate.exchange(url, HttpMethod.GET,null ,new ParameterizedTypeReference<String>(){}) ; 
			
			return responseEntity.getBody();
		}
		
		@RequestMapping(value="/vip")	
		public String vipHome(){
			
			 return "VIP Url:: " + clientContext.getAccessToken().getValue();
		}

}