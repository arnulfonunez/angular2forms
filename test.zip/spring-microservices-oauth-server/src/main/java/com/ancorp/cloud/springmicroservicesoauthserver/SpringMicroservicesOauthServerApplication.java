package com.ancorp.cloud.springmicroservicesoauthserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;


//The oauth server will provide a TOKEN to the calling application based on user id and password.
//then, with the provided password, we can call another service that accepts the token.
//For this excercise, we'll have the oath authentication server and the rest application
//that will be using the token as part of the same project, but these should be two 
//separate applications.


@SpringBootApplication
@EnableAuthorizationServer
public class SpringMicroservicesOauthServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMicroservicesOauthServerApplication.class, args);
	}
}
