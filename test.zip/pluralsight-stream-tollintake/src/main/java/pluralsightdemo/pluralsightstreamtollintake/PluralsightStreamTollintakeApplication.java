package pluralsightdemo.pluralsightstreamtollintake;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.cloud.stream.messaging.Sink;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.handler.annotation.SendTo;


//THIS RECEIVES messages from the queue
////This application will fetch messages from rabbitmq. RabbitMQ messaging service must be running
//@EnableBinding(Sink.class)
//@SpringBootApplication
//public class PluralsightStreamTollintakeApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(PluralsightStreamTollintakeApplication.class, args);
//	}
//	
//	
//	//@StreamListener(Sink.INPUT)
//	@ServiceActivator(inputChannel=Sink.INPUT)  //This is just another configuration to receive message
//	public void log(String msg){
//		System.out.println(msg);
//	}
//}


//THIS RECEIVES AND CAN SEND MESSAGES FROM/TO QUEUES
//@EnableBinding(Processor.class)
//@SpringBootApplication
//public class PluralsightStreamTollintakeApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(PluralsightStreamTollintakeApplication.class, args);
//	}
//	
//	
//	@StreamListener(Processor.INPUT)  
//	@SendTo(Processor.OUTPUT)  //This indicates where to send the return value
//	public String log(String msg){ //To be a processor, it needs to return something
//		
//		System.out.println(msg);
//		return msg;
//	}
//}



@EnableBinding(Sink.class)
@SpringBootApplication
public class PluralsightStreamTollintakeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PluralsightStreamTollintakeApplication.class, args);
	}
	
	//We can have a separate listener based on the header
	@StreamListener(target=Sink.INPUT, condition="headers['speed'] > 40")  
	public void logfast(String msg){ 
		System.out.println("fast - " + msg);
	}
	
	
	@StreamListener(target=Sink.INPUT, condition="headers['speed'] <= 40")  
	public void logslow(String msg){ 
		System.out.println("Slow - " + msg);
	}
}

