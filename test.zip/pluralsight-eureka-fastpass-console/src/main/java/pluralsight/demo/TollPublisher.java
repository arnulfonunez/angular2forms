package pluralsight.demo;

import java.util.Random;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.support.MessageBuilder;

//This class will send a message to RabbitMQ every second. RabbitMQ messaging service must be running.
//@EnableBinding(Source.class) This uses the default source
@EnableBinding(TollSource.class) //This uses the custom source
public class TollPublisher {
	
	//This will cause stream to call this method every second
	//	@InboundChannelAdapter(channel=Source.OUTPUT) 
	//	public String sendTollChange(){
	//		return "{stations:\"20\",customerid:\"100\", timestamp:\"2017-10-17T03:15:00\"}";
	//	}

	
	Random random = new Random();
	
	//POLLING EXAMPLE
//	@InboundChannelAdapter(channel="fastpassTollChannel",poller=@Poller (fixedDelay="2000"))
//	public MessageSource<Toll> sendTollChange(){
//		Toll toll = new Toll("20", "100", "2017-10-17T03:15:00");
//		//	return () -> MessageBuilder.withPayload(toll).build();
//		
//		//We can also send headers as part of the message. This is an example.
//		return () -> MessageBuilder.withPayload(toll).setHeader("speed", Integer.valueOf(random.nextInt(8) * 10)).build();
//	}


	//@InboundChannelAdapter(channel="fastpassTollChannel",poller=@Poller (fixedDelay="2000"))
	public MessageSource<Toll> sendTollChange(){
		Toll toll = new Toll("20", "100", "2017-10-17T03:15:00");
		//	return () -> MessageBuilder.withPayload(toll).build();
		
		//We can also send headers as part of the message. This is an example.
		return () -> MessageBuilder.withPayload(toll).setHeader("speed", Integer.valueOf(random.nextInt(8) * 10)).build();
	}

	
	class Toll {
		public String stationId;
		public String customerId;
		public String timestamp;
		
		public Toll(String stationId, String customerId, String timestamp){
			this.stationId = stationId;
			this.customerId = customerId;
			this.timestamp =timestamp;
		}
		
	}
	

	
}
