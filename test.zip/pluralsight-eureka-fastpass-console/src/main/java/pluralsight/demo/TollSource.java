package pluralsight.demo;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

//This is a custom source for the message queue stream. We can use this one when 
//we want to use features other than the default Source. For instance, send messages every 2 seconds instead
//of every one second.
public interface TollSource {

	@Output("fastpassTollChannel")
	MessageChannel fastpassToll();
	
	@Output("standardTollChannel")
	MessageChannel standardToll();
	
}
