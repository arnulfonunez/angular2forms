package com.ancorp.cloud.springmicroservicesoauth2secureauthserver;

//import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
//import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configurers.GlobalAuthenticationConfigurerAdapter;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;;

@Configuration
public class WebSecurityConfig extends GlobalAuthenticationConfigurerAdapter  {

	@Override
	public void init(AuthenticationManagerBuilder auth) throws Exception{
		auth.inMemoryAuthentication()
		.withUser("user").password("user").roles("USER")
		.and()
		.withUser("admin").password("admin").roles("ADMIN")
		.and()
		.withUser("both").password("both").roles("USER","ADMIN");
	}
	
}


//public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
//	
//	@Bean
//	public AuthenticationManager authenticationManagerBean() throws Exception{
//		
//		return super.authenticationManagerBean();
//	}
//	
//	@Override
//	protected void configure(AuthenticationManagerBuilder auth) throws Exception{
//		auth.inMemoryAuthentication()
//		.withUser("user").password("user").roles("USER")
//		.and()
//		.withUser("admin").password("admin").roles("ADMIN")
//		.and()
//		.withUser("both").password("both").roles("USER","ADMIN");
//	}
//	
//}