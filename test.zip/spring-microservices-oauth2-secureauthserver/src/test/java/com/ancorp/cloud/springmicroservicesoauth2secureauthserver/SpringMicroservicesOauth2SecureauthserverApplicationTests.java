package com.ancorp.cloud.springmicroservicesoauth2secureauthserver;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringMicroservicesOauth2SecureauthserverApplicationTests {

	@Test
	public void contextLoads() {
	}

}
