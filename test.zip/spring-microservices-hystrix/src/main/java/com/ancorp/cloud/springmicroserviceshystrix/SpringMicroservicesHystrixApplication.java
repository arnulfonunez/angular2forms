package com.ancorp.cloud.springmicroserviceshystrix;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@SpringBootApplication
@RestController
@EnableEurekaClient
//@EnableCircuitBreaker //EnableHystrix will also apply the enablecircuitbreaker
@EnableHystrix
@EnableHystrixDashboard
public class SpringMicroservicesHystrixApplication {

	//Hystrix dashboard url: http://localhost:8881/hystrix.stream
	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringMicroservicesHystrixApplication.class, args);
	}
	
	 
	@Autowired
	private RestTemplate restTemplate;

	
	@Bean
	@LoadBalanced
	public RestTemplate getRestTemplate(){
		return new RestTemplate();
	}
	
	@RequestMapping(value="/startClient", method=RequestMethod.GET)
	@HystrixCommand(fallbackMethod="failoverMessage", commandProperties={
			@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds", value="500")
	})
	public String startClient(){

			return this.restTemplate.getForObject("http://CONFIG-CLIENT/message", String.class);
	}
	
	public String failoverMessage(){
		return "This is a default message";
	}
	
	
	
}
