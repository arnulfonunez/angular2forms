package com.ancorp.cloud.springmicroserviceconfigclient;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@RefreshScope
public class ConfigHolder {
	
//	@Autowired
//	private RestTemplate restTemplate;
		
	
	@Value("${message}")
	private String message;
	
	public String getMessage(){
		
//		return this.restTemplate.
//				getForObject("http://MICROSERVICES-CONFIG-SERVER/config-client-development.properties", String.class);
		return this.message;
		}

}
