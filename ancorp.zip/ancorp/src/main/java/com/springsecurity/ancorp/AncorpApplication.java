package com.springsecurity.ancorp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class AncorpApplication {

	public static void main(String[] args) {
		
		//System.setProperty("spring.session.store-type", "redis");
		System.setProperty("spring.session.store-type", "none");
		
		SpringApplication.run(AncorpApplication.class, args);
		
		
	}

	
	
	@Bean
	public BCryptPasswordEncoder getPasswordEncoder(){
		
		return new BCryptPasswordEncoder();
	}
	

//	@Autowired
//	private UserDetailsService userDetailsService;
	
//	@Bean
//	 public DaoAuthenticationProvider authenticationProvider() {
//        DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
//        authenticationProvider.setUserDetailsService(userDetailsService);
//        authenticationProvider.setPasswordEncoder(getPasswordEncoder());
//        return authenticationProvider;
//    }

	
}