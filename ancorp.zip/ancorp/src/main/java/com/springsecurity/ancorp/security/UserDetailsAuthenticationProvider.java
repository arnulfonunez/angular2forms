package com.springsecurity.ancorp.security;

import java.util.Arrays;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component

public class UserDetailsAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider {

	
	
	

//The value returned by spring security should already be encoded. This can also be used if we are creating passwords
//and we want to persist into database.
//This is not needed if using user details service	
	
	@Autowired	
private BCryptPasswordEncoder passwordEncoder; 
	
	
@Override
	protected void additionalAuthenticationChecks(UserDetails paramUserDetails,UsernamePasswordAuthenticationToken paramUsernamePasswordAuthenticationToken) throws AuthenticationException {
		
		System.out.println("additionalAuthenticationChecks");

	}

	@Override
	protected UserDetails retrieveUser(String userName,UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
		
   	 // Get data from databaser based on user name User user = userRepository.findByUsername(username);
   	 //Get the user information from the database. Create the UserDetails object and spring security will compara the values.

        if (userName == null) {
            throw new  UsernameNotFoundException("Invalid user");
        }
        
        if (!userName.equalsIgnoreCase("user")) {
            throw new  UsernameNotFoundException("Invalid user");
        }
		
		String password = authentication.getCredentials().toString(); 
		String password2 = passwordEncoder.encode("password"); //Option 1 compare from database hashedPasswdFromDb
		
		if(!passwordEncoder.matches(password, password2))
		{
			throw new  UsernameNotFoundException("Invalid user");
		}
		
		 // Invoke your webservice here
	    //GrantedAuthority[] grantedAuth = loginWebService.login(username, password);
		
		GrantedAuthority grantedAuthority = new SimpleGrantedAuthority("USER");
		
		//public User(String username, String password, boolean enabled, boolean accountNonExpired, boolean credentialsNonExpired, boolean accountNonLocked, Collection<? extends GrantedAuthority> authorities)
		boolean enabled = true;
		boolean accountNonExpired = true;
		boolean credentialsNonExpired = true;
		boolean accountNonLocked = true;
		
        UserDetails user  = new User(userName, password,enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, Arrays.asList(grantedAuthority));
        
		    return user;
	}
}