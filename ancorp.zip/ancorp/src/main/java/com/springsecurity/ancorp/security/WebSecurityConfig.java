package com.springsecurity.ancorp.security;



import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;


@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	@Autowired
	private AuthenticationProvider authenticationProvider;

	@Autowired	
	private BCryptPasswordEncoder passwordEncoder; 

	
	
//	@Bean
//	public UserDetailsService userDetailsService()  {
////		InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
////		manager.createUser(User.withUsername("user").password("password").roles("USER").build());
////		return manager;
//		
//		return new MyUserDetailsService();
//		
//	}

	  @Override
	    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		  
	        auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder);
	        
	        //auth.authenticationProvider(authenticationProvider);
	    }

	
	protected void configure(HttpSecurity http) throws Exception{
	  http
	  .authorizeRequests().anyRequest().authenticated()
	  .and()
	  .httpBasic()
	  .and()
	  .formLogin().loginPage("/api/login").permitAll()
	  
	  ;
	  
	  http.exceptionHandling().authenticationEntryPoint(new AlwaysSendUnauthorized401AuthenticationEntryPoint());
	}

	
	private class AlwaysSendUnauthorized401AuthenticationEntryPoint implements AuthenticationEntryPoint {

		@Override
		public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException)
				throws IOException, ServletException {
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
		}
	}
	
}
