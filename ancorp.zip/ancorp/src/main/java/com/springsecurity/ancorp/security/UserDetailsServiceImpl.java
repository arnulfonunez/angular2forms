package com.springsecurity.ancorp.security;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
//import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class UserDetailsServiceImpl implements UserDetailsService {
	
	
	
	@Autowired	
	private BCryptPasswordEncoder passwordEncoder; 

	
	 @Override
	    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	        try {
	        	
	        	 // Get data from databaser based on user name User user = userRepository.findByUsername(username);
	        	 //Get the user information from the database. Create the UserDetails object and spring security will compara the values.
	        	
	             if (username == null) {
	                 throw new  UsernameNotFoundException("Invalid user");
	             }
	             
	             if (!username.equalsIgnoreCase("user")) {
	                 throw new  UsernameNotFoundException("Invalid user");
	             }
	             
	             //Because I added the password encoder to the UserDetailsService definition
	             //I don't have to inject the passwordencoder on this class if the database
	             //already has the password encoded. Use the UserDetailsAuthenticationProvider if I need
	             //Access to the password.
	             GrantedAuthority grantedAuthority = new SimpleGrantedAuthority("USER");
	             
	             
	             boolean enabled = true;
	     		 boolean accountNonExpired = true;
	     		 boolean credentialsNonExpired = true;
	     		 boolean accountNonLocked = true;
	     		 //User user  = new User(username, passwordEncoder.encode("password"), Arrays.asList(grantedAuthority));
	             UserDetails user  = new User(username, passwordEncoder.encode("password"),enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, Arrays.asList(grantedAuthority));
	             
	             
	             return user;
	             
	        }
	        catch (Exception e){
	            throw new UsernameNotFoundException("User not found");
	        }
	    }
}